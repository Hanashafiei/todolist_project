SECRET_KEY='thkjhfhj.,utreglthu[lgj461]34~fghjhdg72565fhfd'
PORT=1010
MYSQL_CONFIG="mysql+mysqlconnector://root:@localhost/Todolist"