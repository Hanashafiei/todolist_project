from flask import Blueprint,render_template
from extentions import * 

general=Blueprint("general_blueprint",__name__)

@general.route('/')
def home():
    return render_template("home.html")


@general.route('/about')
def about():
    return render_template("about.html")